package ldg.mybatis.repository.mapper;

public interface ReplyMapper {
}