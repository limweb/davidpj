package ldg.mybatis.model;

public class StaticSample {
	public static final Long[] commentNos = {1L, 2L};

	public static Long getCommentNo1() {
		return 1L;
	}

}
