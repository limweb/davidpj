package com.shopsthai.david.persistence;

import com.shopsthai.david.model.Userinfo;

public interface UserinfoMapper {
    int deleteByPrimaryKey(Integer no);

    int insert(Userinfo record);

    int insertSelective(Userinfo record);

    Userinfo selectByPrimaryKey(Integer no);

    int updateByPrimaryKeySelective(Userinfo record);

    int updateByPrimaryKey(Userinfo record);
}