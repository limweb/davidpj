package com.shopsthai.david.model;

import java.util.Date;

public class Comment {
    private Long comment_no;

    private String user_id;

    private Date reg_date;

    private String comment_content;

    public Comment(Long comment_no, String user_id, Date reg_date, String comment_content) {
        this.comment_no = comment_no;
        this.user_id = user_id;
        this.reg_date = reg_date;
        this.comment_content = comment_content;
    }

    public Long getComment_no() {
        return comment_no;
    }

    public String getUser_id() {
        return user_id;
    }

    public Date getReg_date() {
        return reg_date;
    }

    public String getComment_content() {
        return comment_content;
    }
}