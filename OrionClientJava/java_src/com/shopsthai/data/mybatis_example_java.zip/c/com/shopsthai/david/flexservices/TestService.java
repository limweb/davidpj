package com.shopsthai.david.flexservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import com.shopsthai.david.model.Product;
import com.shopsthai.david.persistence.ProductMapper;


@Service
@RemotingDestination
public class TestService {

	@Autowired
	private  ProductMapper productMapper;
	
	@RemotingInclude
	public Product selectProduct() {
		return productMapper.selectByPrimaryKey(1); 
	}
	
}
