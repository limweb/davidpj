package com.shopsthai.david.persistence;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SET;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.UPDATE;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;
import static org.apache.ibatis.jdbc.SqlBuilder.WHERE;

import com.shopsthai.david.model.Reply;

public class ReplySqlProvider {

    public String insertSelective(Reply record) {
        BEGIN();
        INSERT_INTO("reply");
        
        if (record.getCommentNo() != null) {
            VALUES("comment_no", "#{commentNo,jdbcType=BIGINT}");
        }
        
        if (record.getUserId() != null) {
            VALUES("user_id", "#{userId,jdbcType=VARCHAR}");
        }
        
        if (record.getReplyContent() != null) {
            VALUES("reply_content", "#{replyContent,jdbcType=VARCHAR}");
        }
        
        if (record.getRegDate() != null) {
            VALUES("reg_date", "#{regDate,jdbcType=TIMESTAMP}");
        }
        
        return SQL();
    }

    public String updateByPrimaryKeySelective(Reply record) {
        BEGIN();
        UPDATE("reply");
        
        if (record.getCommentNo() != null) {
            SET("comment_no = #{commentNo,jdbcType=BIGINT}");
        }
        
        if (record.getUserId() != null) {
            SET("user_id = #{userId,jdbcType=VARCHAR}");
        }
        
        if (record.getReplyContent() != null) {
            SET("reply_content = #{replyContent,jdbcType=VARCHAR}");
        }
        
        if (record.getRegDate() != null) {
            SET("reg_date = #{regDate,jdbcType=TIMESTAMP}");
        }
        
        WHERE("reply_no = #{replyNo,jdbcType=BIGINT}");
        
        return SQL();
    }
}