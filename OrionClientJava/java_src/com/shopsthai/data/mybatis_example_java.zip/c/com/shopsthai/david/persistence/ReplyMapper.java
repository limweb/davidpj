package com.shopsthai.david.persistence;

import com.shopsthai.david.model.Reply;
import java.util.Date;
import org.apache.ibatis.annotations.Arg;
import org.apache.ibatis.annotations.ConstructorArgs;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

public interface ReplyMapper {
    @Delete({
        "delete from reply",
        "where reply_no = #{replyNo,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long replyNo);

    @Insert({
        "insert into reply (comment_no, user_id, ",
        "reply_content, reg_date)",
        "values (#{commentNo,jdbcType=BIGINT}, #{userId,jdbcType=VARCHAR}, ",
        "#{replyContent,jdbcType=VARCHAR}, #{regDate,jdbcType=TIMESTAMP})"
    })
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="replyNo", before=false, resultType=Long.class)
    int insert(Reply record);

    @InsertProvider(type=ReplySqlProvider.class, method="insertSelective")
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="replyNo", before=false, resultType=Long.class)
    int insertSelective(Reply record);

    @Select({
        "select",
        "reply_no, comment_no, user_id, reply_content, reg_date",
        "from reply",
        "where reply_no = #{replyNo,jdbcType=BIGINT}"
    })
    @ConstructorArgs({
        @Arg(column="reply_no", javaType=Long.class, jdbcType=JdbcType.BIGINT, id=true),
        @Arg(column="comment_no", javaType=Long.class, jdbcType=JdbcType.BIGINT),
        @Arg(column="user_id", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reply_content", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reg_date", javaType=Date.class, jdbcType=JdbcType.TIMESTAMP)
    })
    Reply selectByPrimaryKey(Long replyNo);

    @UpdateProvider(type=ReplySqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(Reply record);

    @Update({
        "update reply",
        "set comment_no = #{commentNo,jdbcType=BIGINT},",
          "user_id = #{userId,jdbcType=VARCHAR},",
          "reply_content = #{replyContent,jdbcType=VARCHAR},",
          "reg_date = #{regDate,jdbcType=TIMESTAMP}",
        "where reply_no = #{replyNo,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Reply record);
}