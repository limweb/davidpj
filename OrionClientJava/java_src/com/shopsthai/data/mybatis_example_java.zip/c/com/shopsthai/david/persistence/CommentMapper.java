package com.shopsthai.david.persistence;

import com.shopsthai.david.model.Comment;
import com.shopsthai.david.model.CommentExample;
import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Arg;
import org.apache.ibatis.annotations.ConstructorArgs;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

public interface CommentMapper {
    @SelectProvider(type=CommentSqlProvider.class, method="countByExample")
    int countByExample(CommentExample example);

    @DeleteProvider(type=CommentSqlProvider.class, method="deleteByExample")
    int deleteByExample(CommentExample example);

    @Delete({
        "delete from comment",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long comment_no);

    @Insert({
        "insert into comment (user_id, reg_date, ",
        "comment_content)",
        "values (#{user_id,jdbcType=VARCHAR}, #{reg_date,jdbcType=TIMESTAMP}, ",
        "#{comment_content,jdbcType=LONGVARCHAR})"
    })
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="comment_no", before=false, resultType=Long.class)
    int insert(Comment record);

    @InsertProvider(type=CommentSqlProvider.class, method="insertSelective")
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="comment_no", before=false, resultType=Long.class)
    int insertSelective(Comment record);

    @SelectProvider(type=CommentSqlProvider.class, method="selectByExampleWithBLOBs")
    @ConstructorArgs({
        @Arg(column="comment_no", javaType=Long.class, jdbcType=JdbcType.BIGINT, id=true),
        @Arg(column="user_id", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reg_date", javaType=Date.class, jdbcType=JdbcType.TIMESTAMP),
        @Arg(column="comment_content", javaType=String.class, jdbcType=JdbcType.LONGVARCHAR)
    })
    List<Comment> selectByExampleWithBLOBs(CommentExample example);

    @SelectProvider(type=CommentSqlProvider.class, method="selectByExample")
    @ConstructorArgs({
        @Arg(column="comment_no", javaType=Long.class, jdbcType=JdbcType.BIGINT, id=true),
        @Arg(column="user_id", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reg_date", javaType=Date.class, jdbcType=JdbcType.TIMESTAMP)
    })
    List<Comment> selectByExample(CommentExample example);

    @Select({
        "select",
        "comment_no, user_id, reg_date, comment_content",
        "from comment",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    @ConstructorArgs({
        @Arg(column="comment_no", javaType=Long.class, jdbcType=JdbcType.BIGINT, id=true),
        @Arg(column="user_id", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reg_date", javaType=Date.class, jdbcType=JdbcType.TIMESTAMP),
        @Arg(column="comment_content", javaType=String.class, jdbcType=JdbcType.LONGVARCHAR)
    })
    Comment selectByPrimaryKey(Long comment_no);

    @UpdateProvider(type=CommentSqlProvider.class, method="updateByExampleSelective")
    int updateByExampleSelective(@Param("record") Comment record, @Param("example") CommentExample example);

    @UpdateProvider(type=CommentSqlProvider.class, method="updateByExampleWithBLOBs")
    int updateByExampleWithBLOBs(@Param("record") Comment record, @Param("example") CommentExample example);

    @UpdateProvider(type=CommentSqlProvider.class, method="updateByExample")
    int updateByExample(@Param("record") Comment record, @Param("example") CommentExample example);

    @UpdateProvider(type=CommentSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(Comment record);

    @Update({
        "update comment",
        "set user_id = #{user_id,jdbcType=VARCHAR},",
          "reg_date = #{reg_date,jdbcType=TIMESTAMP},",
          "comment_content = #{comment_content,jdbcType=LONGVARCHAR}",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    int updateByPrimaryKeyWithBLOBs(Comment record);

    @Update({
        "update comment",
        "set user_id = #{user_id,jdbcType=VARCHAR},",
          "reg_date = #{reg_date,jdbcType=TIMESTAMP}",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Comment record);
}