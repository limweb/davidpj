package com.shopsthai.david.model;

import java.util.Date;

public class Reply {
    private Long replyNo;

    private Long commentNo;

    private String userId;

    private String replyContent;

    private Date regDate;

    public Reply(Long replyNo, Long commentNo, String userId, String replyContent, Date regDate) {
        this.replyNo = replyNo;
        this.commentNo = commentNo;
        this.userId = userId;
        this.replyContent = replyContent;
        this.regDate = regDate;
    }

    public Long getReplyNo() {
        return replyNo;
    }

    public Long getCommentNo() {
        return commentNo;
    }

    public String getUserId() {
        return userId;
    }

    public String getReplyContent() {
        return replyContent;
    }

    public Date getRegDate() {
        return regDate;
    }
}