package com.shopsthai.david.persistence;

import com.shopsthai.david.model.Reply;
import com.shopsthai.david.model.ReplyExample;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

public interface ReplyMapper {
    int countByExample(ReplyExample example);

    int deleteByExample(ReplyExample example);

    @Delete({
        "delete from reply",
        "where reply_no = #{reply_no,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long reply_no);

    @Insert({
        "insert into reply (comment_no, user_id, ",
        "reply_content, reg_date)",
        "values (#{comment_no,jdbcType=BIGINT}, #{user_id,jdbcType=VARCHAR}, ",
        "#{reply_content,jdbcType=VARCHAR}, #{reg_date,jdbcType=TIMESTAMP})"
    })
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="reply_no", before=false, resultType=Long.class)
    int insert(Reply record);

    int insertSelective(Reply record);

    List<Reply> selectByExample(ReplyExample example);

    @Select({
        "select",
        "reply_no, comment_no, user_id, reply_content, reg_date",
        "from reply",
        "where reply_no = #{reply_no,jdbcType=BIGINT}"
    })
    @ResultMap("BaseResultMap")
    Reply selectByPrimaryKey(Long reply_no);

    int updateByExampleSelective(@Param("record") Reply record, @Param("example") ReplyExample example);

    int updateByExample(@Param("record") Reply record, @Param("example") ReplyExample example);

    int updateByPrimaryKeySelective(Reply record);

    @Update({
        "update reply",
        "set comment_no = #{comment_no,jdbcType=BIGINT},",
          "user_id = #{user_id,jdbcType=VARCHAR},",
          "reply_content = #{reply_content,jdbcType=VARCHAR},",
          "reg_date = #{reg_date,jdbcType=TIMESTAMP}",
        "where reply_no = #{reply_no,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Reply record);
}