package com.shopsthai.david.persistence;

import com.shopsthai.david.model.Comment;
import com.shopsthai.david.model.CommentExample;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

public interface CommentMapper {
    int countByExample(CommentExample example);

    int deleteByExample(CommentExample example);

    @Delete({
        "delete from comment",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long comment_no);

    @Insert({
        "insert into comment (user_id, reg_date, ",
        "comment_content)",
        "values (#{user_id,jdbcType=VARCHAR}, #{reg_date,jdbcType=TIMESTAMP}, ",
        "#{comment_content,jdbcType=LONGVARCHAR})"
    })
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="comment_no", before=false, resultType=Long.class)
    int insert(Comment record);

    int insertSelective(Comment record);

    List<Comment> selectByExampleWithBLOBs(CommentExample example);

    List<Comment> selectByExample(CommentExample example);

    @Select({
        "select",
        "comment_no, user_id, reg_date, comment_content",
        "from comment",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    @ResultMap("ResultMapWithBLOBs")
    Comment selectByPrimaryKey(Long comment_no);

    int updateByExampleSelective(@Param("record") Comment record, @Param("example") CommentExample example);

    int updateByExampleWithBLOBs(@Param("record") Comment record, @Param("example") CommentExample example);

    int updateByExample(@Param("record") Comment record, @Param("example") CommentExample example);

    int updateByPrimaryKeySelective(Comment record);

    @Update({
        "update comment",
        "set user_id = #{user_id,jdbcType=VARCHAR},",
          "reg_date = #{reg_date,jdbcType=TIMESTAMP},",
          "comment_content = #{comment_content,jdbcType=LONGVARCHAR}",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    int updateByPrimaryKeyWithBLOBs(Comment record);

    @Update({
        "update comment",
        "set user_id = #{user_id,jdbcType=VARCHAR},",
          "reg_date = #{reg_date,jdbcType=TIMESTAMP}",
        "where comment_no = #{comment_no,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Comment record);
}