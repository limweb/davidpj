package com.shopsthai.david.persistence;

import com.shopsthai.david.model.Reply;
import com.shopsthai.david.model.ReplyExample;
import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Arg;
import org.apache.ibatis.annotations.ConstructorArgs;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

public interface ReplyMapper {
    @SelectProvider(type=ReplySqlProvider.class, method="countByExample")
    int countByExample(ReplyExample example);

    @DeleteProvider(type=ReplySqlProvider.class, method="deleteByExample")
    int deleteByExample(ReplyExample example);

    @Delete({
        "delete from reply",
        "where reply_no = #{reply_no,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long reply_no);

    @Insert({
        "insert into reply (comment_no, user_id, ",
        "reply_content, reg_date)",
        "values (#{comment_no,jdbcType=BIGINT}, #{user_id,jdbcType=VARCHAR}, ",
        "#{reply_content,jdbcType=VARCHAR}, #{reg_date,jdbcType=TIMESTAMP})"
    })
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="reply_no", before=false, resultType=Long.class)
    int insert(Reply record);

    @InsertProvider(type=ReplySqlProvider.class, method="insertSelective")
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="reply_no", before=false, resultType=Long.class)
    int insertSelective(Reply record);

    @SelectProvider(type=ReplySqlProvider.class, method="selectByExample")
    @ConstructorArgs({
        @Arg(column="reply_no", javaType=Long.class, jdbcType=JdbcType.BIGINT, id=true),
        @Arg(column="comment_no", javaType=Long.class, jdbcType=JdbcType.BIGINT),
        @Arg(column="user_id", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reply_content", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reg_date", javaType=Date.class, jdbcType=JdbcType.TIMESTAMP)
    })
    List<Reply> selectByExample(ReplyExample example);

    @Select({
        "select",
        "reply_no, comment_no, user_id, reply_content, reg_date",
        "from reply",
        "where reply_no = #{reply_no,jdbcType=BIGINT}"
    })
    @ConstructorArgs({
        @Arg(column="reply_no", javaType=Long.class, jdbcType=JdbcType.BIGINT, id=true),
        @Arg(column="comment_no", javaType=Long.class, jdbcType=JdbcType.BIGINT),
        @Arg(column="user_id", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reply_content", javaType=String.class, jdbcType=JdbcType.VARCHAR),
        @Arg(column="reg_date", javaType=Date.class, jdbcType=JdbcType.TIMESTAMP)
    })
    Reply selectByPrimaryKey(Long reply_no);

    @UpdateProvider(type=ReplySqlProvider.class, method="updateByExampleSelective")
    int updateByExampleSelective(@Param("record") Reply record, @Param("example") ReplyExample example);

    @UpdateProvider(type=ReplySqlProvider.class, method="updateByExample")
    int updateByExample(@Param("record") Reply record, @Param("example") ReplyExample example);

    @UpdateProvider(type=ReplySqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(Reply record);

    @Update({
        "update reply",
        "set comment_no = #{comment_no,jdbcType=BIGINT},",
          "user_id = #{user_id,jdbcType=VARCHAR},",
          "reply_content = #{reply_content,jdbcType=VARCHAR},",
          "reg_date = #{reg_date,jdbcType=TIMESTAMP}",
        "where reply_no = #{reply_no,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Reply record);
}