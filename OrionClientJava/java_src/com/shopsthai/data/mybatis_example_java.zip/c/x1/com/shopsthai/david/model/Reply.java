package com.shopsthai.david.model;

import java.util.Date;

public class Reply {
    private Long reply_no;

    private Long comment_no;

    private String user_id;

    private String reply_content;

    private Date reg_date;

    public Reply(Long reply_no, Long comment_no, String user_id, String reply_content, Date reg_date) {
        this.reply_no = reply_no;
        this.comment_no = comment_no;
        this.user_id = user_id;
        this.reply_content = reply_content;
        this.reg_date = reg_date;
    }

    public Long getReply_no() {
        return reply_no;
    }

    public Long getComment_no() {
        return comment_no;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getReply_content() {
        return reply_content;
    }

    public Date getReg_date() {
        return reg_date;
    }
}